package com.exception;

public class SeatsNotAvailableException extends Exception {
public SeatsNotAvailableException() {
	super("Seats Not Available Exception");
}
}
